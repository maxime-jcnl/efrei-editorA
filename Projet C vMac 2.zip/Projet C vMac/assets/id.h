//
// Created by Maxime on 23/04/2023.
//

#ifndef PROJET_C_VMAC_ID_H
#define PROJET_C_VMAC_ID_H
#include "struct.h"
#include "function.h"

unsigned int get_next_id();


#endif //PROJET_C_VMAC_ID_H
